/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'es-mx', {
	clear: 'Borrar',
	highlight: 'Realce',
	options: 'Opciones de color',
	selected: 'Color seleccionado',
	title: 'Selecciona un color'
} );
