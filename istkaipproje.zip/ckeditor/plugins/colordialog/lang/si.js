/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'si', {
	clear: 'පැහැදිලි',
	highlight: 'මතුකර පෙන්වන්න',
	options: 'වර්ණ විකල්ප',
	selected: 'තෙරු වර්ණ',
	title: 'වර්ණ තෝරන්න'
} );
